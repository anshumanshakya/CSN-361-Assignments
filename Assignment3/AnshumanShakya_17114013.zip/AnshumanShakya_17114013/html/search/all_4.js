var searchData=
[
  ['recvfile',['recvFile',['../problem2__client_8c.html#a0d285ee71db2ee39e24c4a6e552991f3',1,'problem2_client.c']]]
];
