var searchData=
[
  ['cipher',['Cipher',['../problem2__client_8c.html#a4fc6ad5854f646cf1e284f66e104219f',1,'Cipher(char ch):&#160;problem2_client.c'],['../problem2__server_8c.html#a4fc6ad5854f646cf1e284f66e104219f',1,'Cipher(char ch):&#160;problem2_server.c']]],
  ['clearbuf',['clearBuf',['../problem2__client_8c.html#a37e9b2e0b0fcbe7d2d5bd9c9467c1fb8',1,'clearBuf(char *b):&#160;problem2_client.c'],['../problem2__server_8c.html#a37e9b2e0b0fcbe7d2d5bd9c9467c1fb8',1,'clearBuf(char *b):&#160;problem2_server.c']]]
];
