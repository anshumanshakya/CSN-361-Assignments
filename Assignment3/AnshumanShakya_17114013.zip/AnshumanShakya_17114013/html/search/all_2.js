var searchData=
[
  ['main',['main',['../problem1_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;problem1.c'],['../problem2__client_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;problem2_client.c'],['../problem2__server_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;problem2_server.c']]]
];
