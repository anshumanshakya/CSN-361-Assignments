var searchData=
[
  ['sendfile',['sendFile',['../problem2__server_8c.html#a19fc2d7afbfbca5d5b78534e8eeb6b29',1,'problem2_server.c']]],
  ['separate',['separate',['../problem1_8c.html#a5f90e3b26836b8a0ff338c925198593d',1,'problem1.c']]]
];
