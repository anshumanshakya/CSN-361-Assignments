var searchData=
[
  ['main',['main',['../problem1__client_8c.html#abf9e6b7e6f15df4b525a2e7705ba3089',1,'main(int argc, char const *argv[]):&#160;problem1_client.c'],['../problem1__server_8c.html#abf9e6b7e6f15df4b525a2e7705ba3089',1,'main(int argc, char const *argv[]):&#160;problem1_server.c']]]
];
