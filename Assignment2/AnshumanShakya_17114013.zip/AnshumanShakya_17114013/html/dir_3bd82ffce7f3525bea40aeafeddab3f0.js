var dir_3bd82ffce7f3525bea40aeafeddab3f0 =
[
    [ "Computer Networks", "dir_3dc0d3267133b75bfc8f10c54267d1b2.html", "dir_3dc0d3267133b75bfc8f10c54267d1b2" ]
];