var dir_d1ffefcc82721506873558668bd9ee24 =
[
    [ "problem1_client.c", "problem1__client_8c.html", "problem1__client_8c" ],
    [ "problem1_server.c", "problem1__server_8c.html", "problem1__server_8c" ],
    [ "problem2.c", "problem2_8c.html", "problem2_8c" ]
];